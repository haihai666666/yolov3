# 基于神经网络的单阶段目标检测器

以下是pytorch版本的YOLOv3代码

[code]（https://github.com/eriklindernoren/PyTorch-YOLOv3）

该代码仓库仍处于持续更新中，因此本目录下的代码与教材编写阶段的代码存在细微差别，读者可以访问上述链接获得最新的代码。

# 使用方法

## 安装代码依赖的环境

```
sudo pip3 install -r requirements.txt
```

## 下载预训练的模型参数

```
cd weights/
bash download_weights.sh
```

## 下载COCO数据集

```
cd data/
bash get_coco_dataset.sh
```

## 测试代码

```
python3 test.py --weights_path weights/yolov3.weights
```

## 在COCO数据集上训练模型

```
python3 train.py --data_config config/coco.data  --pretrained_weights weights/darknet53.conv.74
```

## 自定义训练

通过提供不同的命令行参数，即可控制模型训练的配置
```
python3 train.py [-h] [--epochs EPOCHS] [--batch_size BATCH_SIZE]
                    [--gradient_accumulations GRADIENT_ACCUMULATIONS]
                    [--model_def MODEL_DEF] [--data_config DATA_CONFIG]
                    [--pretrained_weights PRETRAINED_WEIGHTS] [--n_cpu N_CPU]
                    [--img_size IMG_SIZE]
                    [--checkpoint_interval CHECKPOINT_INTERVAL]
                    [--evaluation_interval EVALUATION_INTERVAL]
                    [--compute_map COMPUTE_MAP]
                    [--multiscale_training MULTISCALE_TRAINING]
```